library;

String sharedText = "Initial Data";
